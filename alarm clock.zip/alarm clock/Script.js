// ===== Bible Verses =====
const bibleVerses = [
    "John 3:16 - For God so loved the world that He gave His only Son.",
    "Psalm 23:1 - The Lord is my shepherd; I shall not want.",
    "Philippians 4:13 - I can do all things through Christ who strengthens me.",
    "Romans 8:28 - And we know that in all things God works for the good of those who love Him."
];

// ===== TTS =====
function speakVerse(text) {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "en-US";
    utterance.rate = 0.9;
    speechSynthesis.speak(utterance);
}

// ===== Show Verse =====
function getVerse() {
    const verse = bibleVerses[Math.floor(Math.random() * bibleVerses.length)];
    document.getElementById("verse").innerText = "📖 " + verse;
    speakVerse(verse);
}

// ===== Save Favorite Verses =====
function saveFavoriteVerse() {
    const verse = document.getElementById("verse").innerText.replace("📖 ", "");
    let favorites = JSON.parse(localStorage.getItem("favorites") || "[]");
    favorites.push(verse);
    localStorage.setItem("favorites", JSON.stringify(favorites));
    alert("✅ Saved to favorites!");
}

function showFavorites() {
    let favorites = JSON.parse(localStorage.getItem("favorites") || "[]");
    if(favorites.length === 0) {
        alert("No favorite verses yet.");
    } else {
        alert("Your Favorites:\n" + favorites.join("\n"));
    }
}

// ===== Alarm =====
let alarmTime = localStorage.getItem("alarmTime") || null;
if(alarmTime) document.getElementById("alarmTime").value = alarmTime;

function setAlarm() {
    alarmTime = document.getElementById("alarmTime").value;
    if(alarmTime){
        localStorage.setItem("alarmTime", alarmTime);
        alert("✅ Alarm set for " + alarmTime);
    }
}

// ===== Check Alarm Every Minute =====
setInterval(() => {
    if(!alarmTime) return;
    const now = new Date();
    const hours = String(now.getHours()).padStart(2,'0');
    const minutes = String(now.getMinutes()).padStart(2,'0');
    if(alarmTime === `${hours}:${minutes}`) {
        alert("⏰ Time for your Bible study!"); 
        getVerse();
        alarmTime = null; // Optional: one-time alarm
        localStorage.removeItem("alarmTime");
    }
}, 60000);